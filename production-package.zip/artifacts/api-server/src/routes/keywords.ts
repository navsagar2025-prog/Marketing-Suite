import { Router, type IRouter } from "express";
import { eq, and, gte, desc, inArray } from "drizzle-orm";
import { db, keywordsTable, keywordRankHistoryTable, keywordResearchSessionsTable, websitesTable } from "@workspace/db";
import {
  ListKeywordsQueryParams,
  ListKeywordsResponse,
  CreateKeywordBody,
  UpdateKeywordParams,
  UpdateKeywordBody,
  UpdateKeywordResponse,
  DeleteKeywordParams,
  GetKeywordRankHistoryParams,
  GetKeywordRankHistoryQueryParams,
  GetKeywordRankHistoryResponse,
  ResearchKeywordsBody,
  ResearchKeywordsResponse,
  GetKeywordTrendsQueryParams,
  GetKeywordRankAlertsQueryParams,
} from "@workspace/api-zod";
import { callAI } from "../lib/ai-provider.js";
import { checkAndIncrementUsage } from "../lib/ai-usage.js";

const router: IRouter = Router();

router.get("/keywords", async (req, res): Promise<void> => {
  const query = ListKeywordsQueryParams.safeParse(req.query);
  let keywords;
  if (query.success && query.data.websiteId) {
    keywords = await db.select().from(keywordsTable).where(eq(keywordsTable.websiteId, query.data.websiteId)).orderBy(keywordsTable.createdAt);
  } else {
    keywords = await db.select().from(keywordsTable).orderBy(keywordsTable.createdAt);
  }
  res.json(ListKeywordsResponse.parse(keywords));
});

router.post("/keywords", async (req, res): Promise<void> => {
  const parsed = CreateKeywordBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [keyword] = await db.insert(keywordsTable).values(parsed.data).returning();
  res.status(201).json(keyword);
});

router.post("/keywords/bulk", async (req, res): Promise<void> => {
  const { websiteId, rows } = req.body as {
    websiteId?: number;
    rows?: Array<{ keyword: string; currentRank?: number | null; searchVolume?: number | null; difficulty?: number | null; notes?: string | null }>;
  };
  if (typeof websiteId !== "number" || !Array.isArray(rows) || rows.length === 0) {
    res.status(400).json({ error: "websiteId (number) and rows (non-empty array) are required" });
    return;
  }
  const [website] = await db.select({ id: websitesTable.id }).from(websitesTable).where(eq(websitesTable.id, websiteId));
  if (!website) {
    res.status(404).json({ error: "Website not found" });
    return;
  }

  const cleaned = rows
    .filter(r => r && typeof r.keyword === "string" && r.keyword.trim().length > 0)
    .map(r => ({
      websiteId,
      keyword: r.keyword.trim().slice(0, 200),
      currentRank: typeof r.currentRank === "number" && Number.isFinite(r.currentRank) ? Math.max(1, Math.min(200, Math.round(r.currentRank))) : null,
      searchVolume: typeof r.searchVolume === "number" && Number.isFinite(r.searchVolume) ? Math.max(0, Math.round(r.searchVolume)) : null,
      difficulty: typeof r.difficulty === "number" && Number.isFinite(r.difficulty) ? Math.max(0, Math.min(100, Math.round(r.difficulty))) : null,
      notes: typeof r.notes === "string" ? r.notes.slice(0, 500) : null,
      status: "tracking" as const,
    }));

  if (cleaned.length === 0) {
    res.status(400).json({ error: "No valid rows (keyword text is required)" });
    return;
  }

  const seen = new Set<string>();
  const unique = cleaned.filter(r => {
    const key = r.keyword.toLowerCase();
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  const existing = await db
    .select({ keyword: keywordsTable.keyword })
    .from(keywordsTable)
    .where(eq(keywordsTable.websiteId, websiteId));
  const existingSet = new Set(existing.map(e => e.keyword.toLowerCase()));
  const toInsert = unique.filter(r => !existingSet.has(r.keyword.toLowerCase()));

  if (toInsert.length === 0) {
    res.json({ inserted: 0, skipped: cleaned.length, message: "All keywords already exist" });
    return;
  }

  const inserted = await db.insert(keywordsTable).values(toInsert).returning();
  res.json({
    inserted: inserted.length,
    skipped: cleaned.length - inserted.length,
    duplicatesInFile: cleaned.length - unique.length,
  });
});


router.get("/keywords/research/history", async (req, res): Promise<void> => {
  const userId = req.user!.id;
  const sessions = await db
    .select()
    .from(keywordResearchSessionsTable)
    .where(eq(keywordResearchSessionsTable.staffUserId, userId))
    .orderBy(desc(keywordResearchSessionsTable.createdAt))
    .limit(5);
  res.json(sessions);
});

router.post("/keywords/research", async (req, res): Promise<void> => {
  const userId = req.user!.id;

  const parsed = ResearchKeywordsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { seedInput, websiteId } = parsed.data;

  if (websiteId != null) {
    const [site] = await db.select({ id: websitesTable.id }).from(websitesTable).where(eq(websitesTable.id, websiteId));
    if (!site) {
      res.status(400).json({ error: "Website not found" });
      return;
    }
  }

  const usageCheck = await checkAndIncrementUsage(userId, "text");
  if (!usageCheck.allowed) {
    res.status(429).json({ error: "Monthly text generation limit reached", used: usageCheck.used, limit: usageCheck.limit });
    return;
  }

  const isUrl = /^(https?:\/\/)?[\w-]+(\.[\w-]+)+/.test(seedInput);
  const inputType = isUrl ? "competitor domain" : "seed keyword or topic";

  const prompt = `You are a senior SEO strategist. A user has provided a ${inputType}: "${seedInput}".

Generate 18 high-value keyword ideas that someone targeting this ${inputType} should consider.

For each keyword, provide:
- keyword: the exact keyword phrase (2-5 words, realistic search queries)
- volumeBand: estimated monthly search volume. Use ONLY one of: "<100", "100-1K", "1K-10K", "10K+"
- difficulty: integer 0-100 (0=very easy, 100=impossible). Include a mix — some easy long-tails (difficulty 10-30), some medium (30-60), some hard (60-85)
- intent: ONLY one of: "informational", "commercial", "navigational", "transactional"
- contentAngle: one sentence describing what type of content ranks for this keyword and why it's valuable

Rules:
- Include a mix of short-tail and long-tail keywords
- Include informational AND commercial/transactional keywords
- Prioritise keywords where a business could realistically rank
- Make keyword phrases specific and natural-sounding
- Do NOT include the seed input itself as a suggestion

Return ONLY a valid JSON object like:
{"suggestions": [...]}`;

  try {
    const content = await callAI(prompt, { maxTokens: 3000, jsonMode: true });
    let raw: Record<string, unknown>;
    try {
      raw = JSON.parse(content) as Record<string, unknown>;
    } catch {
      raw = { suggestions: [] };
    }

    const rawSuggestions = Array.isArray(raw["suggestions"]) ? (raw["suggestions"] as unknown[]) : [];
    const validVolumeBands = ["<100", "100-1K", "1K-10K", "10K+"] as const;
    const validIntents = ["informational", "commercial", "navigational", "transactional"] as const;

    const suggestions = rawSuggestions
      .filter((s): s is Record<string, unknown> => typeof s === "object" && s !== null && typeof (s as Record<string, unknown>)["keyword"] === "string")
      .map((s) => ({
        keyword: (s["keyword"] as string).trim(),
        volumeBand: (validVolumeBands as readonly string[]).includes(s["volumeBand"] as string)
          ? (s["volumeBand"] as typeof validVolumeBands[number])
          : "100-1K" as const,
        difficulty: typeof s["difficulty"] === "number" ? Math.min(100, Math.max(0, s["difficulty"])) : 50,
        intent: (validIntents as readonly string[]).includes(s["intent"] as string)
          ? (s["intent"] as typeof validIntents[number])
          : "informational" as const,
        contentAngle: typeof s["contentAngle"] === "string" ? s["contentAngle"] : "",
      }))
      .filter((s) => s.keyword.length > 0);

    const [session] = await db
      .insert(keywordResearchSessionsTable)
      .values({
        staffUserId: userId,
        websiteId: websiteId ?? null,
        seedInput,
        suggestions,
      })
      .returning();

    res.json({ sessionId: session!.id, seedInput, suggestions });
  } catch (err) {
    const message = err instanceof Error ? err.message : "AI generation failed";
    res.status(503).json({ error: message });
  }
});

router.patch("/keywords/:id", async (req, res): Promise<void> => {
  const params = UpdateKeywordParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateKeywordBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [keyword] = await db.update(keywordsTable).set(parsed.data).where(eq(keywordsTable.id, params.data.id)).returning();
  if (!keyword) {
    res.status(404).json({ error: "Keyword not found" });
    return;
  }
  res.json(UpdateKeywordResponse.parse(keyword));
});

router.get("/keywords/:id/history", async (req, res): Promise<void> => {
  const params = GetKeywordRankHistoryParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const queryParsed = GetKeywordRankHistoryQueryParams.safeParse(req.query);
  const rawDays = queryParsed.success && queryParsed.data.days ? queryParsed.data.days : 90;
  const days = Math.min(Math.max(rawDays, 1), 365);

  const [keyword] = await db.select({ id: keywordsTable.id }).from(keywordsTable).where(eq(keywordsTable.id, params.data.id));
  if (!keyword) {
    res.status(404).json({ error: "Keyword not found" });
    return;
  }

  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - days);
  const cutoffDate = cutoff.toISOString().slice(0, 10);

  const history = await db
    .select()
    .from(keywordRankHistoryTable)
    .where(
      and(
        eq(keywordRankHistoryTable.keywordId, params.data.id),
        gte(keywordRankHistoryTable.recordedDate, cutoffDate),
      ),
    )
    .orderBy(keywordRankHistoryTable.recordedDate);

  res.json(GetKeywordRankHistoryResponse.parse(history));
});

router.delete("/keywords/:id", async (req, res): Promise<void> => {
  const params = DeleteKeywordParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [keyword] = await db.delete(keywordsTable).where(eq(keywordsTable.id, params.data.id)).returning();
  if (!keyword) {
    res.status(404).json({ error: "Keyword not found" });
    return;
  }
  res.sendStatus(204);
});

router.get("/keywords/trends", async (req, res): Promise<void> => {
  const queryParsed = GetKeywordTrendsQueryParams.safeParse(req.query);
  const websiteId = queryParsed.success && queryParsed.data.websiteId ? queryParsed.data.websiteId : null;
  const rawDays = queryParsed.success && queryParsed.data.days ? queryParsed.data.days : 30;
  const days = Math.min(Math.max(rawDays, 1), 90);

  const keywords = websiteId
    ? await db.select().from(keywordsTable).where(eq(keywordsTable.websiteId, websiteId)).orderBy(keywordsTable.keyword)
    : await db.select().from(keywordsTable).orderBy(keywordsTable.keyword);

  if (keywords.length === 0) {
    res.json({ keywords: [] });
    return;
  }

  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - days);
  const cutoffDate = cutoff.toISOString().slice(0, 10);

  const kwIds = keywords.map((k) => k.id);
  const history = await db
    .select()
    .from(keywordRankHistoryTable)
    .where(and(inArray(keywordRankHistoryTable.keywordId, kwIds), gte(keywordRankHistoryTable.recordedDate, cutoffDate)))
    .orderBy(keywordRankHistoryTable.recordedDate);

  const historyByKeyword = new Map<number, Array<{ recordedDate: string; rank: number | null }>>();
  for (const h of history) {
    if (!historyByKeyword.has(h.keywordId)) historyByKeyword.set(h.keywordId, []);
    historyByKeyword.get(h.keywordId)!.push({ recordedDate: h.recordedDate, rank: h.rank ?? null });
  }

  const result = keywords.map((kw) => ({
    id: kw.id,
    keyword: kw.keyword,
    websiteId: kw.websiteId,
    history: historyByKeyword.get(kw.id) ?? [],
  }));

  res.json({ keywords: result });
});

router.get("/keywords/rank-alerts", async (req, res): Promise<void> => {
  const queryParsed = GetKeywordRankAlertsQueryParams.safeParse(req.query);
  const websiteId = queryParsed.success && queryParsed.data.websiteId ? queryParsed.data.websiteId : null;

  const keywords = websiteId
    ? await db.select().from(keywordsTable).where(eq(keywordsTable.websiteId, websiteId))
    : await db.select().from(keywordsTable);

  if (keywords.length === 0) {
    res.json({ dropped: [], rising: [] });
    return;
  }

  const kwIds = keywords.map((k) => k.id);

  const eightDaysAgo = new Date();
  eightDaysAgo.setDate(eightDaysAgo.getDate() - 8);
  const cutoffDate = eightDaysAgo.toISOString().slice(0, 10);

  const history = await db
    .select()
    .from(keywordRankHistoryTable)
    .where(and(inArray(keywordRankHistoryTable.keywordId, kwIds), gte(keywordRankHistoryTable.recordedDate, cutoffDate)))
    .orderBy(keywordRankHistoryTable.recordedDate);

  const historyByKeyword = new Map<number, Array<{ recordedDate: string; rank: number | null }>>();
  for (const h of history) {
    if (!historyByKeyword.has(h.keywordId)) historyByKeyword.set(h.keywordId, []);
    historyByKeyword.get(h.keywordId)!.push({ recordedDate: h.recordedDate, rank: h.rank ?? null });
  }

  const sevenDaysAgoStr = (() => {
    const d = new Date();
    d.setDate(d.getDate() - 7);
    return d.toISOString().slice(0, 10);
  })();

  const kwMap = new Map(keywords.map((k) => [k.id, k]));
  const dropped: Array<{ id: number; keyword: string; websiteId: number; currentRank: number | null; previousRank: number | null; delta: number; direction: "up" | "down" }> = [];
  const rising: typeof dropped = [];

  for (const [kwId, entries] of historyByKeyword) {
    const kw = kwMap.get(kwId);
    if (!kw) continue;
    const withRank = entries.filter((e) => e.rank !== null);
    if (withRank.length < 2) continue;
    const newest = withRank[withRank.length - 1];
    const weekOld = [...withRank].reverse().find((e) => e.recordedDate <= sevenDaysAgoStr);
    if (!weekOld || !newest.rank || !weekOld.rank) continue;
    const delta = weekOld.rank - newest.rank;
    if (delta >= 5) {
      rising.push({ id: kwId, keyword: kw.keyword, websiteId: kw.websiteId, currentRank: newest.rank, previousRank: weekOld.rank, delta, direction: "up" });
    } else if (delta <= -5) {
      dropped.push({ id: kwId, keyword: kw.keyword, websiteId: kw.websiteId, currentRank: newest.rank, previousRank: weekOld.rank, delta, direction: "down" });
    }
  }

  res.json({ dropped, rising });
});

export async function runRankSnapshot(): Promise<{ snapshotted: number; skipped: number; failed: number; date: string }> {
  const today = new Date().toISOString().slice(0, 10);
  const keywords = await db.select().from(keywordsTable);
  let snapshotted = 0;
  let skipped = 0;
  let failed = 0;
  for (const kw of keywords) {
    try {
      const result = await db
        .insert(keywordRankHistoryTable)
        .values({ keywordId: kw.id, rank: kw.currentRank ?? null, recordedDate: today })
        .onConflictDoNothing()
        .returning();
      if (result.length > 0) {
        snapshotted++;
      } else {
        skipped++;
      }
    } catch (err) {
      failed++;
      const { logger } = await import("../lib/logger.js");
      logger.error({ keywordId: kw.id, err }, "Keyword snapshot failed for keyword");
    }
  }
  return { snapshotted, skipped, failed, date: today };
}

export default router;
