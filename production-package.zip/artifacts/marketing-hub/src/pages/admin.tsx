import { useState, useMemo, type CSSProperties } from "react";
import {
  DndContext,
  DragOverlay,
  closestCenter,
  PointerSensor,
  KeyboardSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
  type DragStartEvent,
} from "@dnd-kit/core";
import {
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
  arrayMove,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { useAuth } from "@/contexts/AuthContext";
import { useLocation } from "wouter";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Loader2, Trash2, Plus, ShieldCheck, Users, Activity, BarChart2, AlertTriangle, ArrowUpDown, Lock, Unlock, ChevronDown, ChevronUp, ListChecks, ArrowUp, ArrowDown, GripVertical, Copy } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { ALL_MODULES as MODULE_KEYS, MODULE_LABELS } from "@workspace/api-zod";

const DAILY_LIMIT = 2;

const ALL_MODULES = MODULE_KEYS.map(key => ({ key, label: MODULE_LABELS[key] }));

interface AuditRequest {
  id: number;
  ip: string;
  url: string | null;
  date: string;
  count: number;
  lastRequestAt: string;
}

interface AllowlistEntry {
  id: number;
  ip: string;
  note: string | null;
  createdAt: string;
}

interface LockedIp {
  id: number;
  ip: string;
  attempts: number;
  lastAttemptAt: string;
  lockedUntil: string;
}

interface StaffUser {
  id: number;
  username: string;
  email: string | null;
  role: "admin" | "staff";
  permissions: string[] | null;
  plan: "starter" | "growth" | "agency";
  homeDir: string | null;
  createdAt: string;
}

interface VisitorStats {
  uniqueIpsToday: number;
  totalRequestsToday: number;
  totalRequestsAllTime: number;
  ipsAtLimitToday: number;
  dailyData: { date: string; requests: number }[];
}

function useApiHeaders() {
  const { token } = useAuth();
  return { Authorization: `Bearer ${token}` };
}

function useAdminFetch<T>(queryKey: string[], path: string) {
  const headers = useApiHeaders();
  const base = import.meta.env.BASE_URL.replace(/\/$/, "");
  return useQuery<T>({
    queryKey,
    queryFn: async () => {
      const res = await fetch(`${base}${path}`, { headers });
      if (!res.ok) throw new Error("Failed to fetch");
      return res.json();
    },
  });
}

type SortField = "ip" | "date" | "count" | "lastRequestAt";
type SortDir = "asc" | "desc";

function VisitorsTab() {
  const { data: stats, isLoading: statsLoading } = useAdminFetch<VisitorStats>(
    ["admin-visitor-stats"],
    "/api/admin/visitor-stats"
  );
  const { data: requests, isLoading: requestsLoading } = useAdminFetch<AuditRequest[]>(
    ["admin-audit-requests"],
    "/api/admin/audit-requests"
  );

  const [dateFilter, setDateFilter] = useState("");
  const [sortField, setSortField] = useState<SortField>("lastRequestAt");
  const [sortDir, setSortDir] = useState<SortDir>("desc");

  function handleSort(field: SortField) {
    if (sortField === field) {
      setSortDir(d => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortField(field);
      setSortDir("desc");
    }
  }

  const filteredAndSorted = useMemo(() => {
    if (!requests) return [];
    let rows = [...requests];
    if (dateFilter) {
      rows = rows.filter(r => r.date === dateFilter);
    }
    rows.sort((a, b) => {
      let av: string | number = a[sortField] ?? "";
      let bv: string | number = b[sortField] ?? "";
      if (sortField === "count") {
        av = Number(av);
        bv = Number(bv);
      }
      if (av < bv) return sortDir === "asc" ? -1 : 1;
      if (av > bv) return sortDir === "asc" ? 1 : -1;
      return 0;
    });
    return rows;
  }, [requests, dateFilter, sortField, sortDir]);

  const chartData = useMemo(() => {
    if (!stats?.dailyData) return [];
    return stats.dailyData.map(d => ({
      ...d,
      label: d.date.slice(5),
    }));
  }, [stats]);

  const statCards = [
    {
      title: "Unique IPs Today",
      value: stats?.uniqueIpsToday ?? 0,
      icon: <Users className="h-4 w-4 text-muted-foreground" />,
    },
    {
      title: "Audits Today",
      value: stats?.totalRequestsToday ?? 0,
      icon: <Activity className="h-4 w-4 text-muted-foreground" />,
    },
    {
      title: "All-Time Audits",
      value: stats?.totalRequestsAllTime ?? 0,
      icon: <BarChart2 className="h-4 w-4 text-muted-foreground" />,
    },
    {
      title: "IPs at Limit Today",
      value: stats?.ipsAtLimitToday ?? 0,
      icon: <AlertTriangle className="h-4 w-4 text-muted-foreground" />,
      highlight: (stats?.ipsAtLimitToday ?? 0) > 0,
    },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {statCards.map(card => (
          <Card key={card.title} className={card.highlight ? "border-destructive/50" : ""}>
            <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
              <CardTitle className="text-xs font-medium text-muted-foreground">{card.title}</CardTitle>
              {card.icon}
            </CardHeader>
            <CardContent>
              {statsLoading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <p className={`text-2xl font-bold ${card.highlight ? "text-destructive" : ""}`}>
                  {card.value.toLocaleString()}
                </p>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Audit Volume — Last 14 Days</CardTitle>
        </CardHeader>
        <CardContent>
          {statsLoading ? (
            <div className="flex justify-center py-8"><Loader2 className="h-6 w-6 animate-spin" /></div>
          ) : (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={chartData} margin={{ top: 4, right: 8, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis
                  dataKey="label"
                  tick={{ fontSize: 11 }}
                  className="text-muted-foreground"
                />
                <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                <Tooltip
                  contentStyle={{ fontSize: 12 }}
                  formatter={(v: number) => [v, "Audits"]}
                  labelFormatter={label => `Date: ${label}`}
                />
                <Bar dataKey="requests" fill="hsl(var(--primary))" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between flex-wrap gap-2">
          <CardTitle className="text-base">Recent Visitor Activity</CardTitle>
          <Input
            type="date"
            value={dateFilter}
            onChange={e => setDateFilter(e.target.value)}
            className="w-auto text-xs h-8"
          />
        </CardHeader>
        <CardContent>
          {requestsLoading ? (
            <div className="flex justify-center py-8"><Loader2 className="h-6 w-6 animate-spin" /></div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="text-muted-foreground border-b">
                    <th className="text-left py-2 font-medium">
                      <button
                        className="flex items-center gap-1 hover:text-foreground"
                        onClick={() => handleSort("ip")}
                      >
                        IP <ArrowUpDown className="h-3 w-3" />
                      </button>
                    </th>
                    <th className="text-left py-2 font-medium">Last Audited URL</th>
                    <th className="text-left py-2 font-medium">
                      <button
                        className="flex items-center gap-1 hover:text-foreground"
                        onClick={() => handleSort("date")}
                      >
                        Date <ArrowUpDown className="h-3 w-3" />
                      </button>
                    </th>
                    <th className="text-right py-2 font-medium">
                      <button
                        className="flex items-center gap-1 hover:text-foreground ml-auto"
                        onClick={() => handleSort("count")}
                      >
                        Requests <ArrowUpDown className="h-3 w-3" />
                      </button>
                    </th>
                    <th className="text-left py-2 font-medium">
                      <button
                        className="flex items-center gap-1 hover:text-foreground"
                        onClick={() => handleSort("lastRequestAt")}
                      >
                        Last Seen <ArrowUpDown className="h-3 w-3" />
                      </button>
                    </th>
                    <th className="text-left py-2 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredAndSorted.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-4 text-center text-muted-foreground">No records found.</td>
                    </tr>
                  ) : filteredAndSorted.map(r => {
                    const hitLimit = r.count >= DAILY_LIMIT;
                    return (
                      <tr
                        key={r.id}
                        className={`border-b last:border-0 hover:bg-muted/30 ${hitLimit ? "bg-destructive/5" : ""}`}
                      >
                        <td className="py-2 font-mono">{r.ip}</td>
                        <td className="py-2 max-w-[180px] truncate text-muted-foreground">{r.url ?? "—"}</td>
                        <td className="py-2">{r.date}</td>
                        <td className="py-2 text-right">{r.count}</td>
                        <td className="py-2 text-muted-foreground">{new Date(r.lastRequestAt).toLocaleString()}</td>
                        <td className="py-2">
                          {hitLimit ? (
                            <Badge variant="destructive" className="text-xs">Limit Hit</Badge>
                          ) : (
                            <Badge variant="secondary" className="text-xs">Active</Badge>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function AllowlistTab() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const { token } = useAuth();
  const base = import.meta.env.BASE_URL.replace(/\/$/, "");
  const headers = { Authorization: `Bearer ${token}`, "Content-Type": "application/json" };

  const { data: lockedIps, isLoading: lockedLoading } = useAdminFetch<LockedIp[]>(
    ["admin-locked-ips"],
    "/api/admin/locked-ips"
  );

  const unlockMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`${base}/api/admin/locked-ips/${id}`, { method: "DELETE", headers });
      if (!res.ok) throw new Error("Failed to unlock");
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-locked-ips"] });
      toast({ title: "IP unlocked" });
    },
    onError: (err: Error) => toast({ title: err.message, variant: "destructive" }),
  });

  const { data, isLoading } = useAdminFetch<AllowlistEntry[]>(["admin-allowlist"], "/api/admin/allowlist");

  const [ipInput, setIpInput] = useState("");
  const [noteInput, setNoteInput] = useState("");

  const addMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch(`${base}/api/admin/allowlist`, {
        method: "POST",
        headers,
        body: JSON.stringify({ ip: ipInput, note: noteInput }),
      });
      if (!res.ok) {
        const d = await res.json();
        throw new Error(d.error ?? "Failed");
      }
      return res.json();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-allowlist"] });
      setIpInput("");
      setNoteInput("");
      toast({ title: "IP added to allowlist" });
    },
    onError: (err: Error) => toast({ title: err.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`${base}/api/admin/allowlist/${id}`, { method: "DELETE", headers });
      if (!res.ok) throw new Error("Failed to delete");
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-allowlist"] });
      toast({ title: "Entry removed" });
    },
    onError: (err: Error) => toast({ title: err.message, variant: "destructive" }),
  });

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Lock className="h-4 w-4 text-destructive" />
            Login Lockouts
          </CardTitle>
        </CardHeader>
        <CardContent>
          {lockedLoading ? (
            <div className="flex justify-center py-8"><Loader2 className="h-6 w-6 animate-spin" /></div>
          ) : !lockedIps?.length ? (
            <p className="text-sm text-muted-foreground text-center py-4">No IPs currently locked out.</p>
          ) : (
            <div className="space-y-2">
              {lockedIps.map(entry => (
                <div key={entry.id} className="flex items-center justify-between py-2 border-b last:border-0" data-testid={`locked-ip-row-${entry.id}`}>
                  <div>
                    <p className="text-sm font-mono font-medium">{entry.ip}</p>
                    <p className="text-xs text-muted-foreground">
                      {entry.attempts} attempt{entry.attempts !== 1 ? "s" : ""} &middot; locked until{" "}
                      {new Date(entry.lockedUntil).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                    </p>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    className="gap-1.5"
                    data-testid={`button-unlock-ip-${entry.id}`}
                    onClick={() => unlockMutation.mutate(entry.id)}
                    disabled={unlockMutation.isPending}
                  >
                    <Unlock className="h-3.5 w-3.5" />
                    Unlock
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">Add IP to Allowlist</CardTitle></CardHeader>
        <CardContent>
          <div className="flex gap-2 flex-wrap">
            <Input
              placeholder="IP address (e.g. 203.0.113.1)"
              value={ipInput}
              onChange={e => setIpInput(e.target.value)}
              className="flex-1 min-w-0"
            />
            <Input
              placeholder="Note (optional)"
              value={noteInput}
              onChange={e => setNoteInput(e.target.value)}
              className="flex-1 min-w-0"
            />
            <Button onClick={() => addMutation.mutate()} disabled={!ipInput || addMutation.isPending}>
              {addMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <><Plus className="h-4 w-4 mr-1" /> Add</>}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">Allowlisted IPs</CardTitle></CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-8"><Loader2 className="h-6 w-6 animate-spin" /></div>
          ) : !data?.length ? (
            <p className="text-sm text-muted-foreground text-center py-4">No IPs allowlisted yet.</p>
          ) : (
            <div className="space-y-2">
              {data.map(entry => (
                <div key={entry.id} className="flex items-center justify-between py-2 border-b last:border-0">
                  <div>
                    <p className="text-sm font-mono font-medium">{entry.ip}</p>
                    {entry.note && <p className="text-xs text-muted-foreground">{entry.note}</p>}
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-destructive hover:text-destructive"
                    onClick={() => deleteMutation.mutate(entry.id)}
                    disabled={deleteMutation.isPending}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function ModuleChecklist({
  selected,
  onChange,
  fullAccess,
  onFullAccessChange,
  idPrefix = "perm",
  disabled = false,
}: {
  selected: string[];
  onChange: (keys: string[]) => void;
  fullAccess: boolean;
  onFullAccessChange: (v: boolean) => void;
  idPrefix?: string;
  disabled?: boolean;
}) {
  function toggle(key: string) {
    if (disabled) return;
    if (selected.includes(key)) {
      onChange(selected.filter(k => k !== key));
    } else {
      onChange([...selected, key]);
    }
  }

  return (
    <div className={`space-y-2 ${disabled ? "opacity-60" : ""}`}>
      <label className={`flex items-center gap-2 select-none ${disabled ? "cursor-not-allowed" : "cursor-pointer"}`} htmlFor={`${idPrefix}-full-access`}>
        <input
          type="checkbox"
          id={`${idPrefix}-full-access`}
          checked={disabled ? true : fullAccess}
          onChange={e => !disabled && onFullAccessChange(e.target.checked)}
          disabled={disabled}
          className="h-4 w-4 rounded border border-input cursor-pointer"
        />
        <span className="text-sm font-medium">Full access (all modules)</span>
      </label>
      {!disabled && !fullAccess && (
        <div className="grid grid-cols-2 gap-1 pt-1 pl-1">
          {ALL_MODULES.map(m => (
            <label key={m.key} className="flex items-center gap-2 cursor-pointer select-none py-0.5" htmlFor={`${idPrefix}-mod-${m.key}`}>
              <input
                type="checkbox"
                id={`${idPrefix}-mod-${m.key}`}
                checked={selected.includes(m.key)}
                onChange={() => toggle(m.key)}
                className="h-4 w-4 rounded border border-input cursor-pointer"
              />
              <span className="text-xs">{m.label}</span>
            </label>
          ))}
        </div>
      )}
    </div>
  );
}

function StaffTab() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const { token, user: currentUser, login } = useAuth();
  const base = import.meta.env.BASE_URL.replace(/\/$/, "");
  const headers = { Authorization: `Bearer ${token}`, "Content-Type": "application/json" };

  const { data, isLoading } = useAdminFetch<StaffUser[]>(["admin-staff"], "/api/admin/staff");

  const [usernameInput, setUsernameInput] = useState("");
  const [passwordInput, setPasswordInput] = useState("");
  const [emailInput, setEmailInput] = useState("");
  const [roleInput, setRoleInput] = useState<"staff" | "admin">("staff");
  const [newUserFullAccess, setNewUserFullAccess] = useState(true);
  const [newUserPermissions, setNewUserPermissions] = useState<string[]>([]);

  const [expandedUserId, setExpandedUserId] = useState<number | null>(null);
  const [editPermissions, setEditPermissions] = useState<string[]>([]);
  const [editFullAccess, setEditFullAccess] = useState(true);
  const [editEmailUserId, setEditEmailUserId] = useState<number | null>(null);
  const [editEmailValue, setEditEmailValue] = useState("");
  const [editHomeDirUserId, setEditHomeDirUserId] = useState<number | null>(null);
  const [editHomeDirValue, setEditHomeDirValue] = useState("");
  const [diskUsage, setDiskUsage] = useState<Record<number, number>>({});

  const updateHomeDirMutation = useMutation({
    mutationFn: async ({ id, homeDir }: { id: number; homeDir: string }) => {
      const res = await fetch(`${base}/api/admin/staff/${id}/home-dir`, {
        method: "PATCH",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify({ homeDir }),
      });
      if (!res.ok) {
        const d = await res.json();
        throw new Error(d.error ?? "Failed");
      }
      return res.json();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-staff"] });
      setEditHomeDirUserId(null);
      setEditHomeDirValue("");
      toast({ title: "Home directory updated" });
    },
    onError: (err: Error) => toast({ title: err.message, variant: "destructive" }),
  });

  async function loadDiskUsage(id: number) {
    try {
      const res = await fetch(`${base}/api/admin/staff/${id}/disk-usage`, { headers });
      if (!res.ok) return;
      const d = await res.json();
      setDiskUsage(prev => ({ ...prev, [id]: d.bytes }));
    } catch {
    }
  }

  function formatBytes(n: number): string {
    if (n < 1024) return `${n} B`;
    if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
    if (n < 1024 * 1024 * 1024) return `${(n / 1024 / 1024).toFixed(1)} MB`;
    return `${(n / 1024 / 1024 / 1024).toFixed(2)} GB`;
  }

  function openPermissionsPanel(staff: StaffUser) {
    if (expandedUserId === staff.id) {
      setExpandedUserId(null);
      return;
    }
    setExpandedUserId(staff.id);
    const hasFullAccess = staff.permissions == null;
    setEditFullAccess(hasFullAccess);
    setEditPermissions(hasFullAccess ? [] : (staff.permissions ?? []));
  }

  const addMutation = useMutation({
    mutationFn: async () => {
      const permissions = roleInput === "admin" ? null : (newUserFullAccess ? null : newUserPermissions);
      const res = await fetch(`${base}/api/admin/staff`, {
        method: "POST",
        headers,
        body: JSON.stringify({
          username: usernameInput,
          password: passwordInput,
          email: emailInput.trim() || undefined,
          role: roleInput,
          permissions,
        }),
      });
      if (!res.ok) {
        const d = await res.json();
        throw new Error(d.error ?? "Failed");
      }
      return res.json();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-staff"] });
      setUsernameInput("");
      setPasswordInput("");
      setEmailInput("");
      setRoleInput("staff");
      setNewUserFullAccess(true);
      setNewUserPermissions([]);
      toast({ title: "Staff account created" });
    },
    onError: (err: Error) => toast({ title: err.message, variant: "destructive" }),
  });

  const updateEmailMutation = useMutation({
    mutationFn: async ({ id, email }: { id: number; email: string }) => {
      const res = await fetch(`${base}/api/admin/staff/${id}/email`, {
        method: "PATCH",
        headers,
        body: JSON.stringify({ email }),
      });
      if (!res.ok) {
        const d = await res.json();
        throw new Error(d.error ?? "Failed");
      }
      return res.json();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-staff"] });
      setEditEmailUserId(null);
      setEditEmailValue("");
      toast({ title: "Email updated" });
    },
    onError: (err: Error) => toast({ title: err.message, variant: "destructive" }),
  });

  const updatePermissionsMutation = useMutation({
    mutationFn: async ({ id, permissions }: { id: number; permissions: string[] | null }) => {
      const res = await fetch(`${base}/api/admin/users/${id}/permissions`, {
        method: "PATCH",
        headers,
        body: JSON.stringify({ permissions }),
      });
      if (!res.ok) {
        const d = await res.json();
        throw new Error(d.error ?? "Failed");
      }
      return res.json();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-staff"] });
      setExpandedUserId(null);
      toast({ title: "Permissions updated" });
    },
    onError: (err: Error) => toast({ title: err.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`${base}/api/admin/staff/${id}`, { method: "DELETE", headers });
      if (!res.ok) {
        const d = await res.json();
        throw new Error(d.error ?? "Failed");
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-staff"] });
      toast({ title: "Staff account removed" });
    },
    onError: (err: Error) => toast({ title: err.message, variant: "destructive" }),
  });

  const updatePlanMutation = useMutation({
    mutationFn: async ({ id, plan }: { id: number; plan: string }) => {
      const res = await fetch(`${base}/api/admin/staff/${id}/plan`, {
        method: "PATCH",
        headers,
        body: JSON.stringify({ plan }),
      });
      if (!res.ok) {
        const d = await res.json();
        throw new Error(d.error ?? "Failed");
      }
      return res.json();
    },
    onSuccess: (_data, { plan }) => {
      qc.invalidateQueries({ queryKey: ["admin-staff"] });
      const label = plan.charAt(0).toUpperCase() + plan.slice(1);
      toast({ title: `Plan updated to ${label}` });
    },
    onError: (err: Error) => toast({ title: err.message, variant: "destructive" }),
  });

  function permissionsSummary(staff: StaffUser) {
    if (staff.role === "admin") return "Full access (admin)";
    if (staff.permissions == null) return "Full access";
    if (staff.permissions.length === 0) return "No modules";
    return `${staff.permissions.length} module${staff.permissions.length !== 1 ? "s" : ""}`;
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Add Staff Account</CardTitle>
          <p className="text-xs text-muted-foreground">Permission changes take effect the next time a staff member logs in.</p>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex gap-2 flex-wrap">
            <Input
              placeholder="Username"
              value={usernameInput}
              onChange={e => setUsernameInput(e.target.value)}
              className="flex-1 min-w-0"
            />
            <Input
              type="password"
              placeholder="Password"
              value={passwordInput}
              onChange={e => setPasswordInput(e.target.value)}
              className="flex-1 min-w-0"
            />
            <Input
              type="email"
              placeholder="Email (optional)"
              value={emailInput}
              onChange={e => setEmailInput(e.target.value)}
              className="flex-1 min-w-0"
            />
            <select
              value={roleInput}
              onChange={e => setRoleInput(e.target.value as "staff" | "admin")}
              className="border rounded-md px-3 text-sm bg-background"
            >
              <option value="staff">Staff</option>
              <option value="admin">Admin</option>
            </select>
            <Button onClick={() => addMutation.mutate()} disabled={!usernameInput || !passwordInput || addMutation.isPending}>
              {addMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <><Plus className="h-4 w-4 mr-1" /> Add</>}
            </Button>
          </div>
          <div className="border rounded-md p-3 bg-muted/30">
            <p className="text-xs font-medium text-muted-foreground mb-2 flex items-center gap-1.5">
              <Lock className="h-3 w-3" /> Module permissions
              {roleInput === "admin" && (
                <span className="ml-1 text-muted-foreground/70">(admins always have full access)</span>
              )}
            </p>
            <ModuleChecklist
              idPrefix="new-user"
              selected={newUserPermissions}
              onChange={setNewUserPermissions}
              fullAccess={newUserFullAccess}
              onFullAccessChange={setNewUserFullAccess}
              disabled={roleInput === "admin"}
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">Staff Accounts</CardTitle></CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-8"><Loader2 className="h-6 w-6 animate-spin" /></div>
          ) : !data?.length ? (
            <p className="text-sm text-muted-foreground text-center py-4">No staff accounts.</p>
          ) : (
            <div className="space-y-1">
              {data.map(staff => (
                <div key={staff.id} className="border-b last:border-0">
                  <div className="flex items-center justify-between py-2.5">
                    <div className="min-w-0 flex-1 mr-2">
                      <p className="text-sm font-medium truncate">{staff.username}</p>
                      {editEmailUserId === staff.id ? (
                        <div className="flex items-center gap-1.5 mt-1">
                          <Input
                            type="email"
                            placeholder="email@example.com"
                            value={editEmailValue}
                            onChange={e => setEditEmailValue(e.target.value)}
                            className="h-6 text-xs py-0 px-2 w-40"
                            onKeyDown={e => {
                              if (e.key === "Enter") updateEmailMutation.mutate({ id: staff.id, email: editEmailValue });
                              if (e.key === "Escape") { setEditEmailUserId(null); setEditEmailValue(""); }
                            }}
                            autoFocus
                          />
                          <Button size="sm" className="h-6 text-xs px-2 py-0" onClick={() => updateEmailMutation.mutate({ id: staff.id, email: editEmailValue })} disabled={updateEmailMutation.isPending}>
                            {updateEmailMutation.isPending ? <Loader2 className="h-3 w-3 animate-spin" /> : "Save"}
                          </Button>
                          <Button size="sm" variant="ghost" className="h-6 text-xs px-2 py-0" onClick={() => { setEditEmailUserId(null); setEditEmailValue(""); }}>Cancel</Button>
                        </div>
                      ) : (
                        <p className="text-xs text-muted-foreground">
                          Created {new Date(staff.createdAt).toLocaleDateString()}
                          {" · "}
                          <span className={staff.permissions?.length === 0 ? "text-destructive" : ""}>
                            {permissionsSummary(staff)}
                          </span>
                          {" · "}
                          <button
                            className="hover:underline cursor-pointer"
                            onClick={() => { setEditEmailUserId(staff.id); setEditEmailValue(staff.email ?? ""); }}
                            title="Set email for password reset"
                          >
                            {staff.email ? staff.email : <span className="text-amber-600 dark:text-amber-400">no email set</span>}
                          </button>
                        </p>
                      )}
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0 ml-2">
                      <select
                        value={staff.plan}
                        aria-label={`Plan for ${staff.username}`}
                        data-testid={`select-plan-${staff.id}`}
                        disabled={updatePlanMutation.isPending}
                        onChange={e => updatePlanMutation.mutate({ id: staff.id, plan: e.target.value })}
                        className="border rounded-md px-2 py-0.5 text-xs bg-background h-7"
                      >
                        <option value="starter">Starter</option>
                        <option value="growth">Growth</option>
                        <option value="agency">Agency</option>
                      </select>
                      <Badge variant={staff.role === "admin" ? "default" : "secondary"} className="text-xs">{staff.role}</Badge>
                      {staff.role === "staff" && staff.id !== currentUser?.id && (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7 text-muted-foreground hover:text-foreground"
                          title="Edit permissions"
                          aria-label={`Edit permissions for ${staff.username}`}
                          data-testid={`button-edit-permissions-${staff.id}`}
                          onClick={() => openPermissionsPanel(staff)}
                        >
                          {expandedUserId === staff.id ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                        </Button>
                      )}
                      {staff.id !== currentUser?.id && (
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-7 px-2 text-xs text-amber-700 hover:text-amber-900"
                          title="Sign in as this user"
                          data-testid={`button-impersonate-${staff.id}`}
                          onClick={async () => {
                            const res = await fetch(`${base}/api/admin/staff/${staff.id}/impersonate`, { method: "POST", headers });
                            if (!res.ok) {
                              const d = await res.json().catch(() => ({}));
                              toast({ title: d.error ?? "Failed to impersonate", variant: "destructive" });
                              return;
                            }
                            const { token: newToken, user: newUser, actor } = await res.json();
                            login(newToken, newUser, actor ? { actorId: actor.id, actorUsername: actor.username } : null);
                            window.location.href = `${base}/`;
                          }}
                        >
                          Impersonate
                        </Button>
                      )}
                      {staff.id !== currentUser?.id && (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7 text-destructive hover:text-destructive"
                          title="Delete account"
                          aria-label={`Delete account ${staff.username}`}
                          data-testid={`button-delete-staff-${staff.id}`}
                          onClick={() => deleteMutation.mutate(staff.id)}
                          disabled={deleteMutation.isPending}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </div>

                  {expandedUserId === staff.id && (
                    <div className="pb-3 px-1 space-y-3">
                      <div className="border rounded-md p-3 bg-muted/30 space-y-3">
                        <p className="text-xs font-medium text-muted-foreground flex items-center gap-1.5">
                          <Lock className="h-3 w-3" /> Edit module access for <strong>{staff.username}</strong>
                        </p>
                        <ModuleChecklist
                          idPrefix={`edit-${staff.id}`}
                          selected={editPermissions}
                          onChange={setEditPermissions}
                          fullAccess={editFullAccess}
                          onFullAccessChange={setEditFullAccess}
                        />
                        <div className="flex gap-2 pt-1">
                          <Button
                            size="sm"
                            onClick={() =>
                              updatePermissionsMutation.mutate({
                                id: staff.id,
                                permissions: editFullAccess ? null : editPermissions,
                              })
                            }
                            disabled={updatePermissionsMutation.isPending}
                          >
                            {updatePermissionsMutation.isPending ? (
                              <Loader2 className="h-3 w-3 animate-spin mr-1" />
                            ) : null}
                            Save
                          </Button>
                          <Button size="sm" variant="ghost" onClick={() => setExpandedUserId(null)}>
                            Cancel
                          </Button>
                        </div>
                      </div>
                      <div className="border rounded-md p-3 bg-muted/30 space-y-2">
                        <p className="text-xs font-medium text-muted-foreground">Home directory (Files page jail)</p>
                        {editHomeDirUserId === staff.id ? (
                          <div className="flex gap-2 items-center">
                            <Input
                              placeholder={`Default: ${staff.username}`}
                              value={editHomeDirValue}
                              onChange={e => setEditHomeDirValue(e.target.value)}
                              className="h-7 text-xs flex-1"
                              data-testid={`input-home-dir-${staff.id}`}
                            />
                            <Button size="sm" className="h-7 px-2 text-xs" onClick={() => updateHomeDirMutation.mutate({ id: staff.id, homeDir: editHomeDirValue })} disabled={updateHomeDirMutation.isPending}>Save</Button>
                            <Button size="sm" variant="ghost" className="h-7 px-2 text-xs" onClick={() => { setEditHomeDirUserId(null); setEditHomeDirValue(""); }}>Cancel</Button>
                          </div>
                        ) : (
                          <div className="flex items-center gap-2 text-xs">
                            <code className="bg-background px-1.5 py-0.5 rounded border font-mono">{staff.homeDir ?? staff.username}</code>
                            <Button size="sm" variant="ghost" className="h-6 px-2 text-xs" onClick={() => { setEditHomeDirUserId(staff.id); setEditHomeDirValue(staff.homeDir ?? ""); }} data-testid={`button-edit-home-dir-${staff.id}`}>Change</Button>
                            <Button size="sm" variant="ghost" className="h-6 px-2 text-xs" onClick={() => loadDiskUsage(staff.id)}>
                              {diskUsage[staff.id] !== undefined ? `Used: ${formatBytes(diskUsage[staff.id])}` : "Show disk usage"}
                            </Button>
                          </div>
                        )}
                        <p className="text-xs text-muted-foreground">Relative path under the file storage root. Path traversal blocked. Defaults to the username if empty.</p>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

interface OnboardingStepConfig {
  id: string;
  label: string;
  href: string;
  enabled: boolean;
  description?: string;
}

const STEP_ID_LABELS: Record<string, string> = {
  add_website: "Add your first website",
  run_audit: "Run a site audit",
  track_keyword: "Track a keyword",
  create_campaign: "Create a campaign",
};

const BUILT_IN_STEP_IDS = new Set(["add_website", "run_audit", "track_keyword", "create_campaign"]);

interface SortableStepCardProps {
  step: OnboardingStepConfig;
  idx: number;
  total: number;
  onToggle: (checked: boolean) => void;
  onLabelChange: (value: string) => void;
  onHrefChange: (value: string) => void;
  onDescChange: (value: string) => void;
  onMoveUp: () => void;
  onMoveDown: () => void;
  onDelete: () => void;
  onDuplicate: () => void;
}

function SortableStepCard({
  step, idx, total,
  onToggle, onLabelChange, onHrefChange, onDescChange,
  onMoveUp, onMoveDown, onDelete, onDuplicate,
}: SortableStepCardProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    setActivatorNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: step.id });

  const style: CSSProperties = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  if (isDragging) {
    return (
      <div
        ref={setNodeRef}
        style={style}
        className="border-2 border-dashed border-muted-foreground/30 rounded-lg p-4 bg-muted/30 h-[72px]"
        data-testid={`onboarding-step-${step.id}`}
      />
    );
  }

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="border rounded-lg p-4 space-y-3 bg-card"
      data-testid={`onboarding-step-${step.id}`}
    >
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2 min-w-0">
          <button
            ref={setActivatorNodeRef}
            {...attributes}
            {...listeners}
            className="cursor-grab active:cursor-grabbing text-muted-foreground/50 hover:text-muted-foreground transition-colors shrink-0 touch-none"
            aria-label="Drag to reorder"
            tabIndex={0}
          >
            <GripVertical className="h-4 w-4" />
          </button>
          <span className="text-xs font-medium text-muted-foreground tabular-nums w-10 shrink-0">
            Step {idx + 1}
          </span>
          <Switch
            id={`step-enabled-${step.id}`}
            checked={step.enabled}
            onCheckedChange={onToggle}
            aria-label={`Enable step: ${STEP_ID_LABELS[step.id] ?? step.label}`}
          />
          <Label
            htmlFor={`step-enabled-${step.id}`}
            className="text-xs text-muted-foreground cursor-pointer select-none"
          >
            {step.enabled ? "Enabled" : "Disabled"}
          </Label>
        </div>
        <div className="flex items-center gap-1 shrink-0">
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6 text-muted-foreground hover:text-foreground"
            aria-label="Move step up"
            disabled={idx === 0}
            onClick={onMoveUp}
          >
            <ArrowUp className="h-3.5 w-3.5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6 text-muted-foreground hover:text-foreground"
            aria-label="Move step down"
            disabled={idx === total - 1}
            onClick={onMoveDown}
          >
            <ArrowDown className="h-3.5 w-3.5" />
          </Button>
          <Badge variant={BUILT_IN_STEP_IDS.has(step.id) ? "outline" : "secondary"} className="text-xs ml-1">
            {BUILT_IN_STEP_IDS.has(step.id) ? (STEP_ID_LABELS[step.id] ?? step.id) : "Custom"}
          </Badge>
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6 text-muted-foreground hover:text-foreground ml-0.5"
            aria-label={`Duplicate step: ${step.label}`}
            data-testid={`duplicate-step-${step.id}`}
            onClick={onDuplicate}
          >
            <Copy className="h-3.5 w-3.5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6 text-destructive hover:text-destructive hover:bg-destructive/10 ml-0.5 disabled:opacity-30 disabled:cursor-not-allowed"
            aria-label={total === 1 ? "Cannot delete the last step" : `Delete step: ${step.label}`}
            title={total === 1 ? "At least one step must remain in the checklist" : undefined}
            data-testid={`delete-step-${step.id}`}
            disabled={total === 1}
            onClick={onDelete}
          >
            <Trash2 className="h-3.5 w-3.5" />
          </Button>
        </div>
      </div>
      <div className="grid gap-2 sm:grid-cols-2">
        <div className="space-y-1">
          <Label htmlFor={`step-label-${step.id}`} className="text-xs font-medium">Label</Label>
          <Input
            id={`step-label-${step.id}`}
            value={step.label}
            onChange={e => onLabelChange(e.target.value)}
            placeholder="Step label"
            className="text-sm h-8"
            disabled={!step.enabled}
          />
        </div>
        <div className="space-y-1">
          <Label htmlFor={`step-href-${step.id}`} className="text-xs font-medium">Link (path)</Label>
          <Input
            id={`step-href-${step.id}`}
            value={step.href}
            onChange={e => onHrefChange(e.target.value)}
            placeholder="/page-path"
            className="text-sm h-8 font-mono"
            disabled={!step.enabled}
          />
        </div>
      </div>
      {!BUILT_IN_STEP_IDS.has(step.id) && (
        <div className="space-y-1">
          <Label htmlFor={`step-desc-${step.id}`} className="text-xs font-medium">
            Description <span className="text-muted-foreground font-normal">(optional — shown as hint text)</span>
          </Label>
          <Input
            id={`step-desc-${step.id}`}
            value={step.description ?? ""}
            onChange={e => onDescChange(e.target.value)}
            placeholder="e.g. Book your kickoff call with our team"
            className="text-sm h-8"
            disabled={!step.enabled}
          />
        </div>
      )}
    </div>
  );
}

function OnboardingTab() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const { token } = useAuth();
  const base = import.meta.env.BASE_URL.replace(/\/$/, "");
  const headers = { Authorization: `Bearer ${token}`, "Content-Type": "application/json" };

  const { data, isLoading } = useQuery<OnboardingStepConfig[]>({
    queryKey: ["admin-onboarding-steps"],
    queryFn: async () => {
      const res = await fetch(`${base}/api/admin/onboarding-steps`, { headers });
      if (!res.ok) throw new Error("Failed to fetch");
      return res.json();
    },
  });

  const [draft, setDraft] = useState<OnboardingStepConfig[] | null>(null);
  const steps = draft ?? data ?? [];

  // New custom step form state
  const [newLabel, setNewLabel] = useState("");
  const [newHref, setNewHref] = useState("/");
  const [newDesc, setNewDesc] = useState("");

  const [activeId, setActiveId] = useState<string | null>(null);
  const activeStep = steps.find(s => s.id === activeId) ?? null;

  // DnD sensors — require 8px movement before drag starts to avoid false triggers on click
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 8 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  );

  function handleDragStart(event: DragStartEvent) {
    setActiveId(String(event.active.id));
  }

  function initDraft(current: OnboardingStepConfig[]) {
    if (!draft) setDraft(current.map(s => ({ ...s })));
  }

  function updateStep(id: string, changes: Partial<OnboardingStepConfig>) {
    setDraft(prev => {
      const current = prev ?? (data ?? []).map(s => ({ ...s }));
      return current.map(s => s.id === id ? { ...s, ...changes } : s);
    });
  }

  function moveStep(id: string, direction: "up" | "down") {
    setDraft(prev => {
      const current = (prev ?? (data ?? [])).map(s => ({ ...s }));
      const idx = current.findIndex(s => s.id === id);
      if (idx === -1) return current;
      const newIdx = direction === "up" ? idx - 1 : idx + 1;
      if (newIdx < 0 || newIdx >= current.length) return current;
      const reordered = [...current];
      [reordered[idx], reordered[newIdx]] = [reordered[newIdx], reordered[idx]];
      return reordered;
    });
  }

  function handleDragEnd(event: DragEndEvent) {
    setActiveId(null);
    const { active, over } = event;
    if (!over || active.id === over.id) return;
    const current = (draft ?? data ?? []).map(s => ({ ...s }));
    const oldIndex = current.findIndex(s => s.id === active.id);
    const newIndex = current.findIndex(s => s.id === over.id);
    if (oldIndex === -1 || newIndex === -1) return;
    setDraft(arrayMove(current, oldIndex, newIndex));
  }

  function deleteStep(id: string) {
    setDraft(prev => (prev ?? (data ?? []).map(s => ({ ...s }))).filter(s => s.id !== id));
  }

  function duplicateStep(id: string) {
    setDraft(prev => {
      const current = (prev ?? (data ?? [])).map(s => ({ ...s }));
      const idx = current.findIndex(s => s.id === id);
      if (idx === -1) return current;
      const original = current[idx];
      const copy: OnboardingStepConfig = {
        ...original,
        id: `custom_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
        label: `Copy of ${original.label}`,
      };
      const next = [...current];
      next.splice(idx + 1, 0, copy);
      return next;
    });
  }

  function addCustomStep() {
    const label = newLabel.trim();
    const href = newHref.trim() || "/";
    if (!label) { toast({ title: "Label is required", variant: "destructive" }); return; }
    if (!href.startsWith("/") && !href.startsWith("http")) {
      toast({ title: 'Link must start with "/" or "http"', variant: "destructive" }); return;
    }
    const id = `custom_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    const newStep: OnboardingStepConfig = { id, label, href, enabled: true, ...(newDesc.trim() ? { description: newDesc.trim() } : {}) };
    const current = (draft ?? data ?? []).map(s => ({ ...s }));
    setDraft([...current, newStep]);
    setNewLabel(""); setNewHref("/"); setNewDesc("");
    toast({ title: "Custom step added — click Save Changes to persist" });
  }

  const saveMutation = useMutation({
    mutationFn: async (steps: OnboardingStepConfig[]) => {
      const res = await fetch(`${base}/api/admin/onboarding-steps`, {
        method: "PUT",
        headers,
        body: JSON.stringify(steps),
      });
      if (!res.ok) {
        const d = await res.json();
        throw new Error(d.error ?? "Failed to save");
      }
      return res.json();
    },
    onSuccess: (saved) => {
      qc.invalidateQueries({ queryKey: ["admin-onboarding-steps"] });
      qc.invalidateQueries({ queryKey: ["onboarding-step-configs"] });
      setDraft(saved);
      toast({ title: "Onboarding steps saved" });
    },
    onError: (err: Error) => toast({ title: err.message, variant: "destructive" }),
  });

  const resetMutation = useMutation({
    mutationFn: async () => {
      const defaults = [
        { id: "add_website", label: "Add your first website", href: "/websites", enabled: true },
        { id: "run_audit", label: "Run a site audit", href: "/websites", enabled: true },
        { id: "track_keyword", label: "Track a keyword", href: "/keywords", enabled: true },
        { id: "create_campaign", label: "Create a campaign", href: "/campaigns", enabled: true },
      ];
      const res = await fetch(`${base}/api/admin/onboarding-steps`, {
        method: "PUT",
        headers,
        body: JSON.stringify(defaults),
      });
      if (!res.ok) {
        const d = await res.json();
        throw new Error(d.error ?? "Failed to reset");
      }
      return res.json();
    },
    onSuccess: (saved) => {
      qc.invalidateQueries({ queryKey: ["admin-onboarding-steps"] });
      qc.invalidateQueries({ queryKey: ["onboarding-step-configs"] });
      setDraft(saved);
      toast({ title: "Onboarding steps reset to defaults" });
    },
    onError: (err: Error) => toast({ title: err.message, variant: "destructive" }),
  });

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <ListChecks className="h-4 w-4 text-primary" />
            <CardTitle className="text-base">Onboarding Checklist Steps</CardTitle>
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            Customise the steps shown to new users in the Getting Started checklist. Toggle steps on or off, edit their label and link, and drag the grip handle to reorder.
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          {isLoading ? (
            <div className="flex justify-center py-8"><Loader2 className="h-6 w-6 animate-spin" /></div>
          ) : (
            <>
              <DndContext
                sensors={sensors}
                collisionDetection={closestCenter}
                onDragStart={handleDragStart}
                onDragEnd={handleDragEnd}
                onDragCancel={() => setActiveId(null)}
              >
                <SortableContext items={steps.map(s => s.id)} strategy={verticalListSortingStrategy}>
                  <div className="space-y-3">
                    {steps.map((step, idx) => (
                      <SortableStepCard
                        key={step.id}
                        step={step}
                        idx={idx}
                        total={steps.length}
                        onToggle={(checked) => { initDraft(data ?? []); updateStep(step.id, { enabled: checked }); }}
                        onLabelChange={(v) => { initDraft(data ?? []); updateStep(step.id, { label: v }); }}
                        onHrefChange={(v) => { initDraft(data ?? []); updateStep(step.id, { href: v }); }}
                        onDescChange={(v) => { initDraft(data ?? []); updateStep(step.id, { description: v }); }}
                        onMoveUp={() => { initDraft(data ?? []); moveStep(step.id, "up"); }}
                        onMoveDown={() => { initDraft(data ?? []); moveStep(step.id, "down"); }}
                        onDelete={() => { initDraft(data ?? []); deleteStep(step.id); }}
                        onDuplicate={() => duplicateStep(step.id)}
                      />
                    ))}
                  </div>
                </SortableContext>
                <DragOverlay dropAnimation={null}>
                  {activeStep ? (
                    <div className="border rounded-lg p-4 bg-card shadow-xl ring-2 ring-primary/20 cursor-grabbing space-y-3 opacity-95">
                      <div className="flex items-center gap-2 min-w-0">
                        <GripVertical className="h-4 w-4 text-muted-foreground/50 shrink-0" />
                        <span className="text-xs font-medium text-muted-foreground tabular-nums w-10 shrink-0">
                          Step {steps.findIndex(s => s.id === activeStep.id) + 1}
                        </span>
                        <span className="text-sm font-medium truncate">{activeStep.label}</span>
                      </div>
                      {activeStep.description && (
                        <p className="text-xs text-muted-foreground pl-6 truncate">{activeStep.description}</p>
                      )}
                    </div>
                  ) : null}
                </DragOverlay>
              </DndContext>

              {/* Add custom step form */}
              <div className="border rounded-lg p-4 space-y-3 border-dashed" data-testid="add-custom-step-form">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Add Custom Step</p>
                <div className="grid gap-2 sm:grid-cols-2">
                  <div className="space-y-1">
                    <Label htmlFor="new-step-label" className="text-xs font-medium">Label <span className="text-destructive">*</span></Label>
                    <Input
                      id="new-step-label"
                      value={newLabel}
                      onChange={e => setNewLabel(e.target.value)}
                      placeholder="e.g. Book your onboarding call"
                      className="text-sm h-8"
                      data-testid="input-custom-step-label"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="new-step-href" className="text-xs font-medium">Link (path or URL) <span className="text-destructive">*</span></Label>
                    <Input
                      id="new-step-href"
                      value={newHref}
                      onChange={e => setNewHref(e.target.value)}
                      placeholder="/page or https://..."
                      className="text-sm h-8 font-mono"
                      data-testid="input-custom-step-href"
                    />
                  </div>
                </div>
                <div className="space-y-1">
                  <Label htmlFor="new-step-desc" className="text-xs font-medium">Description <span className="text-muted-foreground font-normal">(optional hint text)</span></Label>
                  <Input
                    id="new-step-desc"
                    value={newDesc}
                    onChange={e => setNewDesc(e.target.value)}
                    placeholder="e.g. Click the link to schedule a 30-minute kickoff call"
                    className="text-sm h-8"
                    data-testid="input-custom-step-desc"
                  />
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={addCustomStep}
                  data-testid="button-add-custom-step"
                >
                  <Plus className="h-3.5 w-3.5 mr-1" /> Add Step
                </Button>
              </div>

              <div className="flex gap-2 pt-2">
                <Button
                  onClick={() => saveMutation.mutate(steps)}
                  disabled={saveMutation.isPending || !draft}
                  data-testid="save-onboarding-steps"
                >
                  {saveMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : null}
                  Save Changes
                </Button>
                <Button
                  variant="outline"
                  onClick={() => resetMutation.mutate()}
                  disabled={resetMutation.isPending}
                  data-testid="reset-onboarding-steps"
                >
                  {resetMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : null}
                  Reset to Defaults
                </Button>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

interface SecurityEventRow {
  id: number;
  userId: number | null;
  actorId: number | null;
  action: string;
  target: string | null;
  ip: string | null;
  userAgent: string | null;
  details: Record<string, unknown> | null;
  createdAt: string;
}

function SecurityEventsTab() {
  const { token } = useAuth();
  const base = import.meta.env.BASE_URL.replace(/\/$/, "");
  const headers = { Authorization: `Bearer ${token}` };
  const [actionFilter, setActionFilter] = useState("");
  const [userFilter, setUserFilter] = useState("");
  const [sinceFilter, setSinceFilter] = useState("");
  const [untilFilter, setUntilFilter] = useState("");

  const buildQs = () => {
    const qs = new URLSearchParams();
    if (actionFilter) qs.set("action", actionFilter);
    if (userFilter) qs.set("userId", userFilter);
    if (sinceFilter) qs.set("since", new Date(sinceFilter).toISOString());
    if (untilFilter) qs.set("until", new Date(untilFilter).toISOString());
    return qs;
  };

  const { data, isLoading, refetch } = useQuery({
    queryKey: ["admin-security-events", actionFilter, userFilter, sinceFilter, untilFilter],
    queryFn: async () => {
      const r = await fetch(`${base}/api/admin/security-events?${buildQs().toString()}`, { headers });
      if (!r.ok) throw new Error("Failed");
      return r.json() as Promise<SecurityEventRow[]>;
    },
  });

  const { data: actionCounts } = useQuery({
    queryKey: ["admin-security-event-actions"],
    queryFn: async () => {
      const r = await fetch(`${base}/api/admin/security-events/actions`, { headers });
      if (!r.ok) throw new Error("Failed");
      return r.json() as Promise<{ action: string; count: number }[]>;
    },
  });

  const downloadCsv = () => {
    const qs = buildQs();
    qs.set("format", "csv");
    fetch(`${base}/api/admin/security-events?${qs.toString()}`, { headers })
      .then(r => r.blob())
      .then(blob => {
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "security-events.csv";
        a.click();
        URL.revokeObjectURL(url);
      });
  };

  const ACTION_BADGES: Record<string, string> = {
    login_success: "bg-green-500/10 text-green-700 border-green-300",
    login_failure: "bg-amber-500/10 text-amber-700 border-amber-300",
    login_lockout: "bg-red-500/10 text-red-700 border-red-300",
    permission_denied: "bg-red-500/10 text-red-700 border-red-300",
    impersonation_start: "bg-amber-500/10 text-amber-700 border-amber-300",
    impersonation_stop: "bg-blue-500/10 text-blue-700 border-blue-300",
    password_reset_request: "bg-blue-500/10 text-blue-700 border-blue-300",
    password_reset_complete: "bg-green-500/10 text-green-700 border-green-300",
    session_revoke: "bg-slate-500/10 text-slate-700 border-slate-300",
    session_revoke_all: "bg-slate-500/10 text-slate-700 border-slate-300",
    logout: "bg-slate-500/10 text-slate-700 border-slate-300",
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div>
            <CardTitle className="text-base flex items-center gap-2"><Activity className="h-4 w-4" /> Security Audit Log</CardTitle>
            <p className="text-xs text-muted-foreground mt-0.5">All authentication events, permission denials, impersonation actions, and session changes.</p>
          </div>
          <div className="flex items-center gap-2">
            <Button size="sm" variant="outline" onClick={() => refetch()}>Refresh</Button>
            <Button size="sm" variant="outline" onClick={downloadCsv}>Export CSV</Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex gap-2 mb-3 flex-wrap items-end">
          <div>
            <Label className="text-xs">Action</Label>
            <select
              className="h-8 text-xs rounded-md border bg-background px-2 ml-2"
              value={actionFilter}
              onChange={e => setActionFilter(e.target.value)}
              data-testid="filter-action"
            >
              <option value="">All actions</option>
              {actionCounts?.map(a => (
                <option key={a.action} value={a.action}>{a.action} ({a.count})</option>
              ))}
            </select>
          </div>
          <div>
            <Label className="text-xs">User ID</Label>
            <Input
              type="number"
              value={userFilter}
              onChange={e => setUserFilter(e.target.value)}
              className="h-8 w-24 text-xs ml-2 inline-block"
              placeholder="Any"
              data-testid="filter-user-id"
            />
          </div>
          <div>
            <Label className="text-xs">From</Label>
            <Input
              type="datetime-local"
              value={sinceFilter}
              onChange={e => setSinceFilter(e.target.value)}
              className="h-8 w-44 text-xs ml-2 inline-block"
              data-testid="filter-since"
            />
          </div>
          <div>
            <Label className="text-xs">To</Label>
            <Input
              type="datetime-local"
              value={untilFilter}
              onChange={e => setUntilFilter(e.target.value)}
              className="h-8 w-44 text-xs ml-2 inline-block"
              data-testid="filter-until"
            />
          </div>
          {(actionFilter || userFilter || sinceFilter || untilFilter) && (
            <Button size="sm" variant="ghost" onClick={() => { setActionFilter(""); setUserFilter(""); setSinceFilter(""); setUntilFilter(""); }}>Clear</Button>
          )}
        </div>
        {isLoading ? (
          <div className="flex items-center justify-center py-6"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>
        ) : !data?.length ? (
          <p className="text-sm text-muted-foreground py-6 text-center">No events match those filters.</p>
        ) : (
          <div className="overflow-auto max-h-[60vh]">
            <table className="w-full text-xs">
              <thead className="sticky top-0 bg-background border-b">
                <tr className="text-muted-foreground">
                  <th className="text-left p-2">When</th>
                  <th className="text-left p-2">Action</th>
                  <th className="text-left p-2">User</th>
                  <th className="text-left p-2">Actor</th>
                  <th className="text-left p-2">Target</th>
                  <th className="text-left p-2">IP</th>
                </tr>
              </thead>
              <tbody data-testid="security-events-list">
                {data.map(ev => (
                  <tr key={ev.id} className="border-b hover:bg-muted/30">
                    <td className="p-2 text-muted-foreground tabular-nums whitespace-nowrap">{new Date(ev.createdAt).toLocaleString()}</td>
                    <td className="p-2">
                      <span className={cn("inline-block rounded border px-1.5 py-0.5 text-[10px] font-medium", ACTION_BADGES[ev.action] ?? "bg-muted text-foreground border-border")}>
                        {ev.action}
                      </span>
                    </td>
                    <td className="p-2 tabular-nums">{ev.userId ?? "—"}</td>
                    <td className="p-2 tabular-nums">{ev.actorId ?? "—"}</td>
                    <td className="p-2 truncate max-w-[180px]" title={ev.target ?? ""}>{ev.target ?? "—"}</td>
                    <td className="p-2 text-muted-foreground">{ev.ip ?? "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default function AdminPage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  if (user?.role !== "admin") {
    return (
      <div className="p-6 text-center">
        <p className="text-muted-foreground">You don't have admin access.</p>
        <Button className="mt-4" onClick={() => setLocation("/")}>Go to Dashboard</Button>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center gap-3">
        <ShieldCheck className="h-6 w-6 text-primary" />
        <h1 className="text-2xl font-bold font-display">Admin Panel</h1>
      </div>

      <Tabs defaultValue="visitors">
        <TabsList>
          <TabsTrigger value="visitors">Visitors</TabsTrigger>
          <TabsTrigger value="allowlist">Allowlist</TabsTrigger>
          <TabsTrigger value="staff">Staff Accounts</TabsTrigger>
          <TabsTrigger value="onboarding">Onboarding Checklist</TabsTrigger>
          <TabsTrigger value="security" data-testid="tab-security-events">Security Events</TabsTrigger>
        </TabsList>
        <TabsContent value="visitors" className="mt-4">
          <VisitorsTab />
        </TabsContent>
        <TabsContent value="allowlist" className="mt-4">
          <AllowlistTab />
        </TabsContent>
        <TabsContent value="staff" className="mt-4">
          <StaffTab />
        </TabsContent>
        <TabsContent value="onboarding" className="mt-4">
          <OnboardingTab />
        </TabsContent>
        <TabsContent value="security" className="mt-4">
          <SecurityEventsTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}
