import { pgTable, text, serial, timestamp, pgEnum, jsonb, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const staffRoleEnum = pgEnum("staff_role", ["admin", "staff"]);
export const planEnum = pgEnum("staff_plan", ["starter", "growth", "agency"]);

export const staffUsersTable = pgTable("staff_users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").unique(),
  passwordHash: text("password_hash").notNull(),
  role: staffRoleEnum("role").notNull().default("staff"),
  permissions: jsonb("permissions").$type<string[] | null>().default(null),
  plan: planEnum("plan").notNull().default("starter"),
  byokProvider: text("byok_provider"),
  byokApiKey: text("byok_api_key"),
  byokEnabled: boolean("byok_enabled").notNull().default(false),
  homeDir: text("home_dir"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertStaffUserSchema = createInsertSchema(staffUsersTable).omit({ id: true, createdAt: true });
export type InsertStaffUser = z.infer<typeof insertStaffUserSchema>;
export type StaffUser = typeof staffUsersTable.$inferSelect;
